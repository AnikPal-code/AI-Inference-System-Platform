import os
import httpx

SENTIMENT_URL = os.getenv("SENTIMENT_URL")
RESUME_URL = os.getenv("RESUME_URL")
IMAGE_URL = os.getenv("IMAGE_URL")


async def post_json(service_url: str, endpoint: str, payload: dict):
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(
            f"{service_url}{endpoint}",
            json=payload,
        )
        response.raise_for_status()
    return response.json()


async def post_file(service_url: str, endpoint: str, files: dict):
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(
            f"{service_url}{endpoint}",
            files=files,
        )
        response.raise_for_status()
    return response.json()
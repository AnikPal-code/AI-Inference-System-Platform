from fastapi import FastAPI

from .routes import router

app = FastAPI(
    title="AI Gateway",
    version="1.0.0",
)

app.include_router(router)


@app.get("/")
def root():
    return {
        "service": "AI Gateway"
    }


@app.get("/health")
def health():
    return {
        "status": "healthy"
    }
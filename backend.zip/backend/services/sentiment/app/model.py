# This code creates the core ML engine for the app.
# It loads the AI model via transformers and exposes
# a single function to analyze the emotional tone
from transformers import pipeline

sentiment_pipeline = pipeline(
    "sentiment-analysis",
    model="distilbert-base-uncased-finetuned-sst-2-english"
)


def predict_sentiment(text: str):
    return sentiment_pipeline(text)[0]